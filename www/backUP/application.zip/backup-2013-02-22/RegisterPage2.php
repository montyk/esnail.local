<html>
<head>
<title>eSnail.ca - Registration Page 2of2</title>
 <!-- Link to CSS stylesheet -->
 <link href="styles.css"  rel="stylesheet" type="text/css" />
  <script type="text/javascript"  src="javascript.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- Address Bar Icon Link -->

<STYLE TYPE="text/css">
<!--
H2
   {
   color:black;
   font-size:14pt;
   font-style:bold;
      }
H3
   {
   color:black;
   font-size:10pt;
   text-align:left
      }
-->
</STYLE>
<link REL=�SHORTCUT ICON� HREF=�favicon.ico�>
<SCRIPT TYPE="text/javascript">
<!--
function popup(mylink, windowname)
{
if (! window.focus)return true;
var href;
if (typeof(mylink) == 'string')
href=mylink;
else
href=mylink.href;
window.open(href, windowname, 'width=450,height=200	,scrollbars=yes');
return false;
}
//-->
</SCRIPT>


</head>
<center>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- ImageReady Slices (eSnail Order Form 1024x.psd) -->
<table id="Table_01" width="1024" height="881" border="0" cellpadding="0" cellspacing="0" style="background:#6b88c7"> 
	<tr>
		<td colspan="10">
			<img src="registerpage1_01.jpg" width="1024" height="143" alt=""></td>
	</tr>
	<tr>
		<td colspan="3" rowspan="2">
			<a href="index.html"><img src="registerpage1_02.jpg" border="0" width="335" height="202" alt=""></a></td>
		<td>
			<a href="RegisterPage1.php"><img src="registerpage1_03.jpg" border="0" width="137" height="85" alt=""></a></td>
		<td>
			<a href="about.html"><img src="registerpage1_04.jpg" border="0" width="110" height="85" alt=""></a></td>
		<td>
			<a href="faq.html"><img src="registerpage1_05.jpg" border="0" width="92" height="85" alt=""></a></td>
		<td>
			<a href="services.html"><img src="menubar_13.jpg" border="0" width="150" height="85" alt=""></a></td>
		<td colspan="2">
			<a href="contactus.html"><img src="registerpage1_07.jpg" border="0" width="155" height="85" alt=""></a></td>
		<td rowspan="2">
			<img src="registerpage1_08.jpg" width="45" height="202" alt=""></td>
	</tr>
	<tr>
		<td colspan="6">
			<img src="registerpage1_09.jpg" width="644" height="117" alt=""></td>
	</tr>
	<tr>
		<td colspan="2">
			<img src="registerpage1_10.jpg" width="71" height="483" alt=""></td>
		<td colspan="6" valign="top">
			
<p><img src="chooseyourplan.gif"></p>
<p></p>
<b>Thank you for registering.</b>&nbsp Your coupon code will be processed as a refund after your purchase, if you don't have a

promotional now you can still qualify for sale pricing!  Simply reccomend esnail.ca to a friend and when they sign up send us an email mentioning their name and we'll give

you six months free!
<p>&nbsp
<p>&nbsp

<SCRIPT language=javascript>
function CalculateOrder(form)
{

if (form.os0.value == "Pay as You Go")
 {
 form.a3.value = 0.99;
 form.t3.value = "M";
 form.p3.value = "1";
 form.item_name.value = "Yearly Membership"
 form.item_number.value = "Pay-as-you-go-YM";
 }

if (form.os0.value == "Pay as You Go with OCR")
 {
 form.a3.value = 0.99;
 form.t3.value = "M";
 form.item_name.value = "Yearly Membership"
 form.item_number.value = "Pay-as-you-go-OCR-YM";
 }

if (form.os0.value == "Basic Plan")
 {
 form.a3.value = 9.99;
 form.t3.value = "M";
 form.item_name.value = "Yearly Membership"
 form.item_number.value = "BASIC-YM";
 }
 
if (form.os0.value == "Basic Plan with OCR")
 {
 form.a3.value = 14.99;
 form.t3.value = "M";
 form.item_name.value = "Yearly Membership"
 form.item_number.value = "BASIC-OCR-YM";
 }
 
if (form.os0.value == "Personal")
 {
 form.a3.value = 18.99;
 form.t3.value = "M";
 form.item_name.value = "Yearly Membership"
 form.item_number.value = "Personal-YM";
 }

if (form.os0.value == "Personal with OCR")
 {
 form.a3.value = 25.99;
 form.t3.value = "M";
 form.item_name.value = "Yearly Membership"
 form.item_number.value = "Personal-OCR-YM";
 }  
 
if (form.os0.value == "Business")
 {
 form.a3.value = 54.99;
 form.t3.value = "M";
 form.item_name.value = "Yearly Membership"
 form.item_number.value = "Business-YM";
 } 

if (form.os0.value == "Business with OCR")
 {
 form.a3.value = 69.99;
 form.t3.value = "M";
 form.item_name.value = "Yearly Membership"
 form.item_number.value = "Business-OCR-YM";
 }
 
}  
</SCRIPT>

<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="on0" value="Subscription Option">Select your Subscription:&nbsp;&nbsp;
<select name="os0">
<option value="Pay as You Go">Pay as You Go - $0.99/mo</option>
<option value="Pay as You Go with OCR">Pay as You Go with OCR - $0.99/mo</option>

<option selected value="Basic Plan">Basic Plan - $9.99/mo</option>
<option value="Basic Plan with OCR">Basic Plan with OCR - $14.99/mo</option>
<option value="Personal">Personal Plan - $18.99/mo</option>
<option value="Personal with OCR">Personal Plan with OCR - $25.99/mo</option>
<option value="Business">Business - $54.99/mo</option>
<option value="Business with OCR">Business with OCR - $69.99/mo</option>
</select>
<p>&nbsp;</p>
<p align="left"><h3>What's <a 
   HREF="OCRpopup.html" onClick="return popup(this, 'OCR')">OCR?</a></h3></p>
<br><br><br>
<INPUT onclick=CalculateOrder(this.form) type="image" src="https://www.paypal.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
<input type="hidden" name="cmd" value="_xclick-subscriptions">
<input type="hidden" name="business" value="postmaster@esnail.ca">
<input type="hidden" name="item_name">
<input type="hidden" name="item_number">
<input type="hidden" name="no_shipping" value="0">
<input type="hidden" name="return" value="http://www.yoursite.com/success.html">
<input type="hidden" name="cancel_return" value="http://www.yoursite.com/cancel.html">
<input type="hidden" name="no_note" value="1">
<input type="hidden" name="currency_code" value="CAD">
<input type="hidden" name="lc" value="US">
<input type="hidden" name="bn" value="PP-SubscriptionsBF">
<input type="hidden" name="a3">
<input type="hidden" name="p3" value="1">
<input type="hidden" name="t3">
<input type="hidden" name="src" value="1">
<input type="hidden" name="sra" value="1">
</form>



 
            </td>
		<td colspan="2">
			<img src="registerpage1_12.jpg" width="71" height="483" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="registerpage1_13.jpg" width="69" height="52" alt=""></td>
		<td colspan="9">
			<img src="registerpage1_14.jpg" width="955" height="52" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="spacer.gif" width="69" height="1" alt=""></td>
		<td>
			<img src="spacer.gif" width="2" height="1" alt=""></td>
		<td>
			<img src="spacer.gif" width="264" height="1" alt=""></td>
		<td>
			<img src="spacer.gif" width="137" height="1" alt=""></td>
		<td>
			<img src="spacer.gif" width="110" height="1" alt=""></td>
		<td>
			<img src="spacer.gif" width="92" height="1" alt=""></td>
		<td>
			<img src="spacer.gif" width="150" height="1" alt=""></td>
		<td>
			<img src="spacer.gif" width="129" height="1" alt=""></td>
		<td>
			<img src="spacer.gif" width="26" height="1" alt=""></td>
		<td>
			<img src="spacer.gif" width="45" height="1" alt=""></td>
	</tr>
</table>

<!-- End ImageReady Slices -->
</body>
</html>