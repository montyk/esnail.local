<h1>Your message has been sent</h1>
<p>We will contact you shortly via e-mail.</p>