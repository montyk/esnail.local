-- phpMyAdmin SQL Dump
-- version 4.1.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 08, 2014 at 08:53 AM
-- Server version: 5.5.37-MariaDB
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `esnail_website`
--

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `excerpt` varchar(1500) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `added_on`, `excerpt`, `title`, `content`) VALUES
(4, '2012-04-21 13:51:17', '<p><span style="color: #002344; font-family: ''Droid Serif'', Tahoma, Arial, sans-serif; font-size: 13px; line-height: 19px;">It''s nice to see positive change happening in the world. A friend of mine sent me a link to this company in Switzerland which has begun to offer scanning and storage online. Unfortunately they are running the business on the same principle as Earth Class Mail, an Oregon based startup that offers a similar service as eSnail.ca.</span></p>', 'World''s Highest Paid Letter Opener', '<p>It''s nice to see positive change happening in the world. A friend of mine sent me a link to&nbsp;<a href="http://www.post.ch/en/post-startseite/post-swisspostbox.htm">this</a>&nbsp;company in Switzerland which has begun to offer scanning and storage online. Unfortunately they are running the business on the same principle as Earth Class Mail, an Oregon based startup that offers a similar service as eSnail.ca. Basically their service involves scanning the envelope- ONLY the envelope- and then asking the user to pay $1.50 just to send you a scanned copy of the envelope''s actual contents.</p>\n<p>While we wish our friends at Swiss Post and Earth Class Mail the best it seems to us rather silly to make our users wait a full day just to see the contents of their mail- let alone to charge $1.50 for us to use a letter opener. I can''t speak for everyone, but I open every piece of mail with my name on it- which still makes up the bulk of the mail I personally receive. If I kept an account at Earth Class Mail, It would drive me batty wondering what''s in the envelope each time I received and wondering if it was worth it to pay the $1.50 to open it.</p>\n<p>The only thing worse than having a frustrated customer is being a frustrated customer. So let us know how we''re doing.</p>\n<p>Until next entry, have a great day.</p>\n<p>Stephan DuVal<br />eSnail.ca Postmaster</p>'),
(5, '2012-05-02 13:51:56', '<p>A friend of mine who is into marketing once told me that Canada Post is one of the most valuable brands in existence. By that he meant not the service it provides but the goodwill that the name holds with its users who view it as a trustworthy and efficient service.</p>', 'The cost of a PO Box', '<p>A friend of mine who is into marketing once told me that Canada Post is one of the most valuable brands in existence. By that he meant not the service it provides but the goodwill that the name holds with its users who view it as a trustworthy and efficient service. Personally I like Canada Post. I prefer it to companies like UPS, DHL and TNT who principally provide the maddening service of posting those sticky notices telling you that you can''t have your package because you- as you were already aware- were not at home. Isn''t that what a postal box is for? Canada Post has never had trouble delivering or holding on to a package for weeks at a nearby postal outlet- but many of the big courier companies have actually returned packages without my consent because it was not convenient for them to deliver it at a time when I could sign for it.</p>\n<p>According to a Boston.com article, it seems that the US postal service is in a bit of&nbsp;<a style="margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; line-height: inherit; vertical-align: baseline; text-decoration: none;" href="http://articles.boston.com/2012-04-17/business/31356274_1_mail-volume-postal-service-first-class-mail-delivery">trouble</a>&nbsp;lately due to online communication and bills.</p>\n<p>I hope that eSnail.ca is on the side of Canada Post, rather than being one of those companies that are slowly causing it to go the way of the Cotton Gin. Perhaps a day like today is good one to reaffirm that Canada Post is eSnail.ca''s first choice when it comes to forwarding packages and letters. We do this not because it is the most cost-effective option, (though it often is) but because it is the most convenient for our users and because Canada Post offers a high level of service for rural and remote addresses. Canada Post is a company with vision who puts service above convenience and profit. That''s exactly the kind of company eSnail.ca hopes to be.</p>\n<p>Have a great day,</p>\n<p>Stephan DuVal<br />eSnail.ca Postmaster</p>'),
(6, '2013-06-26 13:44:18', '<p>This has been a very exiciting month for us at eSnail.ca. &nbsp;Our Web traffic has tripled this month since we''ve startedd to reach out to Google users.</p>', 'Welcome new visitors', '<p>This has been a very exiciting month for us at eSnail.ca. &nbsp;Our Web traffic has tripled this month since we''ve startedd to reach out to Google users. &nbsp;We hope that in reaching our site you''ve been looping for. Up until this month our customers have mostly found about us through word of mouth and our poster campaigns.&nbsp;</p>\n<p>I''d like to thank Victor Avasiloaei for his hard work on the website and his advice on how to make the webpage searchable.</p>\n<p>We''ve also moved our scanning center to a new, larger, facility with a at number of additional security features.</p>'),
(7, '2013-08-23 21:55:59', '<p><span style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">Your mailing address says a lot about your company. Are you a startup working out of a basement or do you do business in a large commercial center?</span></p>', 'Every small business need a business address', '<p><span style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">Every small business needs an office mailing address. Your mailing address says a lot about your company. Are you a startup working out of a basement or do you do business in a large commercial center? &nbsp;For web-based companies a commercial address tells your customers where you come from and lend your company a brick and mortar image of trust and reliability. &nbsp;It''s part of your identity.</span></p>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">&nbsp;</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">Stability is as important as trust in a small business environment.<br />\n<div>\n<div>&nbsp;</div>\n<div>If you work from home you might never get to meet the potential clients who sees a residential address on your website and feels reluctant to do business with someone who doesn''t have a private office. It''s about the idea that their business is safe with you because you''re here to stay.</div>\n<div>&nbsp;</div>\n<div>Virtual offices or pocket offices are a booming business in major business centers. They provide small startups or individuals with a desk and the resources of a small office for a fraction of the rent. It''s a great concept because its flexible for entrepreneurs. Still, the rent is often in the hundreds of dollars- which can be a lot if you move into a larger office and wish to maintain a permanent business address.</div>\n</div>\n</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">&nbsp;</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">Even if its the right idea in the long term, &nbsp;rebranding, moving locations and renaming your business can hurt your company&nbsp;</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">&nbsp;</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;"><a href="http://eSnail.ca">eSnail.ca</a>&nbsp;is working to create a flexible solution for small and medium businesses who are moving up fast but want their clients to know that they are here to stay.&nbsp;</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">&nbsp;</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">Check out the plans we have to offer and see if</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">&nbsp;</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">Your Company Name</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">\n<div><a href="x-apple-data-detectors://1">115 E Pender St</a></div>\n<div><a href="x-apple-data-detectors://1">Vancouver&lrm; BC&lrm; V6A 1T6</a></div>\n<div><a href="x-apple-data-detectors://1">Canada</a></div>\n</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">&nbsp;</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">Is the right place for you.&nbsp;</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">&nbsp;</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">Sincerely,</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">&nbsp;</div>\n<div style="font-family: ''.Helvetica NeueUI''; font-size: 18px; line-height: 24px; -webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(130, 98, 83, 0.0976563); -webkit-composition-frame-color: rgba(191, 107, 82, 0.496094); -webkit-text-size-adjust: auto;">Stephan DuVal</div>');

-- --------------------------------------------------------

--
-- Table structure for table `ta_login_attempts`
--

CREATE TABLE IF NOT EXISTS `ta_login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(40) COLLATE utf8_bin NOT NULL,
  `login` varchar(50) COLLATE utf8_bin NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ta_login_attempts`
--

INSERT INTO `ta_login_attempts` (`id`, `ip_address`, `login`, `time`) VALUES
(3, '24.84.18.122', 'esnail.ca', '2013-08-23 21:53:34'),
(4, '24.84.18.122', 'esnail.ca', '2013-08-23 21:53:40');

-- --------------------------------------------------------

--
-- Table structure for table `ta_users`
--

CREATE TABLE IF NOT EXISTS `ta_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT '1',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `new_password_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `new_password_requested` datetime DEFAULT NULL,
  `new_email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `new_email_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ta_users`
--

INSERT INTO `ta_users` (`id`, `username`, `password`, `email`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`) VALUES
(1, 'esnail', '$2a$08$NSx9HuzHzESAJYHrF2QLnucGjwYDJnEILdnrqDOHVSahZKmz6R8R.', 'stephan.duval@gmail.com', 1, 0, NULL, NULL, NULL, NULL, NULL, '24.84.18.122', '2013-08-23 17:53:48', '2013-04-26 16:36:45', '2013-08-23 21:53:48');

-- --------------------------------------------------------

--
-- Table structure for table `ta_user_autologin`
--

CREATE TABLE IF NOT EXISTS `ta_user_autologin` (
  `key_id` char(32) COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `ta_user_autologin`
--

INSERT INTO `ta_user_autologin` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES
('8586b449448f67830fd893adf4f52c7d', 1, 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_1_3 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) CriOS/27.0.1453.10 Mobile/10B329 Safari/8536.25', '24.114.41.58', '2013-06-25 21:41:50'),
('8596c4b0b1da44621f1c6f0b189dda63', 1, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31', '127.0.0.1', '2013-04-24 15:02:30'),
('9332baaa022c70495365dfaf7b8071ee', 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', '24.84.18.122', '2013-06-26 13:32:58');

-- --------------------------------------------------------

--
-- Table structure for table `ta_user_profiles`
--

CREATE TABLE IF NOT EXISTS `ta_user_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `country` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ta_user_profiles`
--

INSERT INTO `ta_user_profiles` (`id`, `user_id`, `country`, `website`) VALUES
(1, 1, NULL, NULL),
(2, 1, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
