<?php defined('SYSPATH') OR die('No direct access allowed.');

class Model_User_Token extends Model_Auth_User_Token {

	// This class can be replaced or extended

} // End User Token Model