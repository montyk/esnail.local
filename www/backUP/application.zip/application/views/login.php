<div class="content-box support-page-box">
<p>Our apologies, at this time the user login area is still being set up.<br /> You will still continue receiving your scanned letters and package notifications in your inbox and any account changes can be requested at support@esnail.ca, where a live person will assist you with any requests.</p>
<p>We look forward to serving your better in the future.</p>
<p>The eSnail.ca Team</p>
</div>