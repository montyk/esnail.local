<?php defined('SYSPATH') OR die('No direct script access.');

interface HTTP_Response extends Kohana_HTTP_Response {}
