<div class="topbar">
    <div class="wrapper">
        <ul class="topbar-items">
            <li id="register-button"><a href="/auth/logout">Logout</a></li>
        </ul>
    </div>
</div>
<div class="header">
    <div class="wrapper">
        <div class="logo">
            <a href="/index.html" data-remote="true"><img src="/media/images/logo.png" alt="eSnail"/></a>
            <p>&nbsp;&nbsp;&nbsp;&nbsp;Operating as eSnail.ca Automated Mail Systems Inc.
        </div>
    </div>
</div>