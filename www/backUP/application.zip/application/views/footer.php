<!-- beginning of footer -->
    </div>
</div>
<div class="footer">
	<div class="wrapper">
    	
        <div id="footer-contacts">
        	<p>
            	<strong>eSnail.ca</strong><br />
                Suite One<br />
                115 East Pender St.<br />
                Vancouver‎ BC<br />
                V6A 1T6<br />
                Canada
            </p>
        </div>
        
        <div id="footer-links">
        	<a href="/support/">Support</a> |
        	<a href="/security/">Security</a> |
        	<a href="/faq/">F.A.Q.</a> |
        	<a href="/legal/">Legal</a> |
            <a href="/privacy/">Privacy</a>                                    
        </div>
        
        <div class="clear"></div>
        
    </div>
</div>
<!-- end of footer -->
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-12592801-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>