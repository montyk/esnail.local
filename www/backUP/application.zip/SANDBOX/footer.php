<!-- beginning of footer -->
    </div>
</div>
<div class="footer">
	<div class="wrapper">
    	
        <div id="footer-contacts">
        	<p>
            	<strong>eSnail.ca</strong><br />
                PO BOX 19019<br />
                2302 West 4th Ave.<br />
                Vancouver, BC<br />
                V6K 1R8
            </p>
        </div>
        
        <div id="footer-links">
        	<a href="<?=$base;?>support/">Support</a> |
        	<a href="<?=$base;?>security/">Security</a> |
        	<a href="<?=$base;?>faq/">F.A.Q.</a> |
        	<a href="<?=$base;?>legal/">Legal</a> |
            <a href="<?=$base;?>privacy/">Privacy</a>                                    
        </div>
        
        <div class="clear"></div>
        
    </div>
</div>
<!-- end of footer -->
</body>
</html>