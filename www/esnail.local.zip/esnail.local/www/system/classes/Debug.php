<?php defined('SYSPATH') OR die('No direct script access.');

class Debug extends Kohana_Debug {}
