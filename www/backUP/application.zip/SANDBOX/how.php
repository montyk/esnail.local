<?php include ("header.php"); ?>

<div class="content-box how-page-box">
	<h1>How It Works</h1>
    <p>How should a service like this work?  Well, in the least disruptive way for the customer possible really. For various reasons, mail is still the preferred method of communications for businesses and...</p>
    <div class="wrap">    
    	<table class="how">
        	<tr>
            	<td class="number">1</td>
                <td class="text">Sign up for a personal eSnail address</td>
            </tr>
            <tr>
            	<td class="number">2</td>
                <td class="text">Share your address with your friends</td>
            </tr>
            <tr>
            	<td class="number">3</td>
                <td class="text">eSnail securely scans all your snail mail</td>
            </tr>
            <tr>
            	<td class="number">4</td>
                <td class="text">You receive all your snail mail right in your inbox or you can access and organize all your archived mail through our eLetter interface.</td>
            </tr>
        </table>
    </div>        
</div>
<?php include ("footer.php"); ?>