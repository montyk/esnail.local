<div class="footer">
    <div class="container">
        <p class="text-muted pull-right"><strong>&copy; eSnail.ca 2014</strong></p>
    </div>
</div>