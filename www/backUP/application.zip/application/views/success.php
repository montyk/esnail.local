<div class="content-box how-page-box">
	<h1>Thank you for your payment!</h1>
	<p>One of our operators will contact you shortly and get you set up with your account!</p>
</div>