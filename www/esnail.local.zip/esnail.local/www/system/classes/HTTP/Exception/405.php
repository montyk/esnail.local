<?php defined('SYSPATH') OR die('No direct script access.');

class HTTP_Exception_405 extends Kohana_HTTP_Exception_405 {}
