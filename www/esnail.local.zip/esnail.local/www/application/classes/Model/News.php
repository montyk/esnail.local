<?php defined('SYSPATH') OR die('No direct access allowed.');

class Model_News extends ORM {

}