<?php include("header.php"); ?>
<div class="content-box about-page-box testimonials-page-box">
	<h1>Testimonials</h1>
    <p>Thanks to everyone for their testimonials.  By way of thanks we've credited all your accounts with a month of free service.  </p>
    <p><img src="<?=$base;?>img/testimonials/testimonial_1.jpg" alt="Testimonial" /></p>
    <p><img src="<?=$base;?>img/testimonials/testimonial_2.jpg" alt="Testimonial" /></p>
</div>

<?php include("footer.php"); ?>