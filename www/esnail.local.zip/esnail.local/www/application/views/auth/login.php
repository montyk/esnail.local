
<div class="content-box">
    <h1>Welcome to eSnail.ca</h1>
    <form method="post" accept-charset="utf-8">
        <table id="register-table">
            <tr>
                <td><label for="username1">Username:</label></td>
                <td><input id="username1" type="text" name="username" /></td>
                <td class="td-check" id="firstname-check"></td>
            </tr>
            <tr>
                <td><label for="password1">Password:</label></td>
                <td><input id="password1" type="password" name="password" /></td>
                <td class="td-check" id="lastname-check"></td>
            </tr>
            <tr>
                <td class="subsectionTitle">
                <input class="order-button" type="submit" value="Login">
            </td>
        </table>
    </form>
</div>

